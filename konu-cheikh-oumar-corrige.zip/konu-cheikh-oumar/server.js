require("dotenv").config();
const express = require("express");
const http = require("http");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { Pool } = require("pg");
const { Server } = require("socket.io");
const crypto = require("crypto");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: true, credentials: true } });
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 24) {
  console.warn("WARNING: set JWT_SECRET to a long random value in production.");
}
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.PGSSL === "true" ? { rejectUnauthorized: false } : false
});

app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

function signToken(user) {
  if (!JWT_SECRET) throw new Error("JWT_SECRET is not configured");
  return jwt.sign({ sub: String(user.id), name: user.display_name }, JWT_SECRET, { expiresIn: "7d" });
}
async function auth(req, res, next) {
  try {
    const header = req.headers.authorization || "";
    const token = header.startsWith("Bearer ") ? header.slice(7) : "";
    if (!token) return res.status(401).json({ error: "Connexion requise." });
    const decoded = jwt.verify(token, JWT_SECRET);
    const result = await pool.query(
      "SELECT id, display_name, email, phone FROM users WHERE id=$1", [decoded.sub]
    );
    if (!result.rowCount) return res.status(401).json({ error: "Session invalide." });
    req.user = result.rows[0];
    next();
  } catch (_) {
    return res.status(401).json({ error: "Jeton invalide ou expiré." });
  }
}
const asyncRoute = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

app.get("/api/health", asyncRoute(async (_req, res) => {
  await pool.query("SELECT 1");
  res.json({ ok: true, service: "Konũ Cheikh Oumar", database: "connected" });
}));

app.post("/api/auth/register", asyncRoute(async (req, res) => {
  const { displayName, email, phone, password } = req.body || {};
  const name = String(displayName || "").trim();
  const normalizedEmail = email ? String(email).trim().toLowerCase() : null;
  const normalizedPhone = phone ? String(phone).trim() : null;
  if (!name || name.length > 80) return res.status(400).json({ error: "Nom requis (80 caractères maximum)." });
  if (!normalizedEmail && !normalizedPhone) return res.status(400).json({ error: "Ajoutez un e-mail ou un numéro de téléphone." });
  if (normalizedEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) return res.status(400).json({ error: "Adresse e-mail invalide." });
  if (!password || String(password).length < 8) return res.status(400).json({ error: "Le mot de passe doit contenir au moins 8 caractères." });
  const hash = await bcrypt.hash(String(password), 12);
  try {
    const result = await pool.query(
      "INSERT INTO users(display_name,email,phone,password_hash) VALUES($1,$2,$3,$4) RETURNING id,display_name,email,phone",
      [name, normalizedEmail, normalizedPhone, hash]
    );
    res.status(201).json({ user: result.rows[0], token: signToken(result.rows[0]) });
  } catch (err) {
    if (err.code === "23505") return res.status(409).json({ error: "Cet e-mail ou numéro est déjà utilisé." });
    throw err;
  }
}));

app.post("/api/auth/login", asyncRoute(async (req, res) => {
  const { identifier, password } = req.body || {};
  if (!identifier || !password) return res.status(400).json({ error: "Identifiant et mot de passe requis." });
  const id = String(identifier).trim();
  const result = await pool.query(
    "SELECT id,display_name,email,phone,password_hash FROM users WHERE lower(email)=lower($1) OR phone=$1 LIMIT 1", [id]
  );
  if (!result.rowCount || !(await bcrypt.compare(String(password), result.rows[0].password_hash))) {
    return res.status(401).json({ error: "Identifiants incorrects." });
  }
  const user = result.rows[0];
  delete user.password_hash;
  res.json({ user, token: signToken(user) });
}));

app.get("/api/me", auth, (req, res) => res.json({ user: req.user }));

app.post("/api/groups", auth, asyncRoute(async (req, res) => {
  const name = String(req.body?.name || "").trim();
  const description = String(req.body?.description || "").trim();
  if (!name || name.length > 100) return res.status(400).json({ error: "Nom du groupe requis (100 caractères maximum)." });
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const code = crypto.randomBytes(6).toString("hex").toUpperCase();
    const group = await client.query(
      "INSERT INTO groups(name,description,owner_id,invite_code) VALUES($1,$2,$3,$4) RETURNING id,name,description,owner_id,invite_code,created_at",
      [name, description, req.user.id, code]
    );
    await client.query("INSERT INTO group_members(group_id,user_id,role) VALUES($1,$2,'owner')", [group.rows[0].id, req.user.id]);
    await client.query("COMMIT");
    res.status(201).json({ group: group.rows[0] });
  } catch (e) { await client.query("ROLLBACK"); throw e; }
  finally { client.release(); }
}));

app.get("/api/groups", auth, asyncRoute(async (req, res) => {
  const result = await pool.query(
    `SELECT g.id,g.name,g.description,g.owner_id,g.created_at,gm.role
     FROM groups g JOIN group_members gm ON gm.group_id=g.id
     WHERE gm.user_id=$1 ORDER BY g.created_at DESC`, [req.user.id]
  );
  res.json({ groups: result.rows });
}));

app.post("/api/groups/join-request", auth, asyncRoute(async (req, res) => {
  const code = String(req.body?.inviteCode || "").trim().toUpperCase();
  if (!code) return res.status(400).json({ error: "Code du groupe requis." });
  const g = await pool.query("SELECT id,name,owner_id FROM groups WHERE invite_code=$1", [code]);
  if (!g.rowCount) return res.status(404).json({ error: "Code de groupe inconnu." });
  const group = g.rows[0];
  const member = await pool.query("SELECT 1 FROM group_members WHERE group_id=$1 AND user_id=$2", [group.id, req.user.id]);
  if (member.rowCount) return res.status(409).json({ error: "Vous êtes déjà membre de ce groupe." });
  const request = await pool.query(
    `INSERT INTO join_requests(group_id,user_id) VALUES($1,$2)
     ON CONFLICT(group_id,user_id) DO UPDATE SET status='pending',created_at=NOW()
     RETURNING id,status,created_at`, [group.id, req.user.id]
  );
  io.to(`user:${group.owner_id}`).emit("join-request", {
    groupId: group.id, groupName: group.name, requestId: request.rows[0].id,
    user: { id: req.user.id, displayName: req.user.display_name }, timestamp: Date.now()
  });
  res.status(201).json({ message: "Demande envoyée au propriétaire.", request: request.rows[0] });
}));

app.get("/api/groups/:id/requests", auth, asyncRoute(async (req, res) => {
  const id = Number(req.params.id);
  const owner = await pool.query("SELECT 1 FROM groups WHERE id=$1 AND owner_id=$2", [id, req.user.id]);
  if (!owner.rowCount) return res.status(403).json({ error: "Seul le propriétaire peut consulter les demandes." });
  const result = await pool.query(
    `SELECT jr.id,jr.status,jr.created_at,u.id AS user_id,u.display_name,u.email,u.phone
     FROM join_requests jr JOIN users u ON u.id=jr.user_id
     WHERE jr.group_id=$1 AND jr.status='pending' ORDER BY jr.created_at`, [id]
  );
  res.json({ requests: result.rows });
}));

app.post("/api/groups/:id/requests/:requestId/approve", auth, asyncRoute(async (req, res) => {
  const groupId = Number(req.params.id), requestId = Number(req.params.requestId);
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const owner = await client.query("SELECT id,name FROM groups WHERE id=$1 AND owner_id=$2 FOR UPDATE", [groupId, req.user.id]);
    if (!owner.rowCount) { await client.query("ROLLBACK"); return res.status(403).json({ error: "Action réservée au propriétaire." }); }
    const jr = await client.query(
      "SELECT id,user_id FROM join_requests WHERE id=$1 AND group_id=$2 AND status='pending' FOR UPDATE", [requestId, groupId]
    );
    if (!jr.rowCount) { await client.query("ROLLBACK"); return res.status(404).json({ error: "Demande introuvable ou déjà traitée." }); }
    await client.query("INSERT INTO group_members(group_id,user_id,role) VALUES($1,$2,'member') ON CONFLICT DO NOTHING", [groupId, jr.rows[0].user_id]);
    await client.query("UPDATE join_requests SET status='approved' WHERE id=$1", [requestId]);
    await client.query("COMMIT");
    io.to(`user:${jr.rows[0].user_id}`).emit("request-approved", { groupId, groupName: owner.rows[0].name });
    res.json({ message: "Membre ajouté au groupe." });
  } catch (e) { await client.query("ROLLBACK"); throw e; }
  finally { client.release(); }
}));

app.post("/api/groups/:id/requests/:requestId/reject", auth, asyncRoute(async (req, res) => {
  const groupId = Number(req.params.id), requestId = Number(req.params.requestId);
  const owner = await pool.query("SELECT 1 FROM groups WHERE id=$1 AND owner_id=$2", [groupId, req.user.id]);
  if (!owner.rowCount) return res.status(403).json({ error: "Action réservée au propriétaire." });
  const result = await pool.query(
    "UPDATE join_requests SET status='rejected' WHERE id=$1 AND group_id=$2 AND status='pending' RETURNING id",
    [requestId, groupId]
  );
  if (!result.rowCount) return res.status(404).json({ error: "Demande introuvable ou déjà traitée." });
  res.json({ message: "Demande refusée." });
}));

app.get("/api/groups/:id/messages", auth, asyncRoute(async (req, res) => {
  const groupId = Number(req.params.id);
  const member = await pool.query("SELECT 1 FROM group_members WHERE group_id=$1 AND user_id=$2", [groupId, req.user.id]);
  if (!member.rowCount) return res.status(403).json({ error: "Vous ne faites pas partie de ce groupe." });
  const result = await pool.query(
    `SELECT m.id,m.group_id,m.body,m.created_at,u.id AS user_id,u.display_name
     FROM messages m JOIN users u ON u.id=m.user_id WHERE m.group_id=$1
     ORDER BY m.created_at DESC LIMIT 100`, [groupId]
  );
  res.json({ messages: result.rows.reverse() });
}));

app.get("/api/media", auth, asyncRoute(async (_req, res) => {
  const result = await pool.query(
    `SELECT p.id,p.media_type,p.media_url,p.caption,p.created_at,u.display_name
     FROM media_posts p JOIN users u ON u.id=p.user_id ORDER BY p.created_at DESC LIMIT 100`
  );
  res.json({ posts: result.rows });
}));

app.post("/api/media", auth, asyncRoute(async (req, res) => {
  const { mediaType, mediaUrl, caption } = req.body || {};
  if (!["photo","video","audio"].includes(mediaType) || !mediaUrl || String(mediaUrl).length > 2000) {
    return res.status(400).json({ error: "Type de média ou URL invalide." });
  }
  let parsed;
  try { parsed = new URL(mediaUrl); } catch (_) { return res.status(400).json({ error: "URL invalide." }); }
  if (!["https:","http:"].includes(parsed.protocol)) return res.status(400).json({ error: "Seules les URL HTTP/HTTPS sont autorisées." });
  const result = await pool.query(
    "INSERT INTO media_posts(user_id,media_type,media_url,caption) VALUES($1,$2,$3,$4) RETURNING id,media_type,media_url,caption,created_at",
    [req.user.id, mediaType, mediaUrl, String(caption || "").slice(0,500)]
  );
  res.status(201).json({ post: result.rows[0] });
}));

const sockets = new Map();
io.use((socket, next) => {
  try {
    const token = socket.handshake.auth?.token;
    if (!token) return next(new Error("Authentification requise"));
    socket.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch (_) { next(new Error("Session invalide")); }
});
io.on("connection", socket => {
  const userId = String(socket.user.sub);
  socket.join(`user:${userId}`);
  sockets.set(socket.id, userId);

  socket.on("join-group", async groupId => {
    try {
      const check = await pool.query("SELECT 1 FROM group_members WHERE group_id=$1 AND user_id=$2", [Number(groupId), userId]);
      if (check.rowCount) socket.join(`group:${Number(groupId)}`);
      else socket.emit("app-error", { message: "Accès au groupe refusé." });
    } catch (_) { socket.emit("app-error", { message: "Impossible de rejoindre le groupe." }); }
  });

  socket.on("send-message", async payload => {
    try {
      const groupId = Number(payload?.groupId);
      const body = String(payload?.body || "").trim();
      if (!Number.isSafeInteger(groupId) || !body || body.length > 5000) return;
      const member = await pool.query("SELECT 1 FROM group_members WHERE group_id=$1 AND user_id=$2", [groupId, userId]);
      if (!member.rowCount) return socket.emit("app-error", { message: "Vous ne faites pas partie de ce groupe." });
      const result = await pool.query(
        `INSERT INTO messages(group_id,user_id,body) VALUES($1,$2,$3)
         RETURNING id,group_id,user_id,body,created_at`, [groupId, userId, body]
      );
      const message = { ...result.rows[0], display_name: socket.user.name };
      io.to(`group:${groupId}`).emit("new-message", message);
    } catch (_) { socket.emit("app-error", { message: "Le message n'a pas pu être envoyé." }); }
  });
  socket.on("disconnect", () => sockets.delete(socket.id));
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Erreur serveur. Réessayez plus tard." });
});
server.listen(PORT, () => console.log(`Konũ Cheikh Oumar démarré sur le port ${PORT}`));
