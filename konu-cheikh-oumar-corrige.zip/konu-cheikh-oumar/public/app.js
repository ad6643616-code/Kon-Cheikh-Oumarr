const $ = id => document.getElementById(id);
let token = localStorage.getItem("kco_token");
let currentUser = null, currentGroup = null, socket = null, mode = "login";
const api = async (url, options={}) => {
  const headers = { "Content-Type":"application/json", ...(options.headers||{}) };
  if (token) headers.Authorization = `Bearer ${token}`;
  const response = await fetch(url, {...options, headers});
  const data = await response.json().catch(()=>({error:"Réponse invalide du serveur."}));
  if (!response.ok) throw new Error(data.error || "Une erreur est survenue.");
  return data;
};
function setNotice(id, message, good=false){const el=$(id);el.textContent=message||"";el.style.color=good?"#176b52":"";}
function showAuth(){ $("auth-card").classList.remove("hidden");$("app").classList.add("hidden");if(socket)socket.disconnect();}
function showApp(){ $("auth-card").classList.add("hidden");$("app").classList.remove("hidden");$("welcome-title").textContent=`Bienvenue, ${currentUser.display_name}`;connectSocket();loadGroups();loadMedia();}
document.querySelectorAll(".tab").forEach(btn=>btn.addEventListener("click",()=>{
  mode=btn.dataset.mode;document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b===btn));
  $("name-wrap").classList.toggle("hidden",mode!=="register");$("phone-wrap").classList.toggle("hidden",mode!=="register");
  $("auth-submit").textContent=mode==="register"?"Créer mon compte":"Se connecter";
  $("password").autocomplete=mode==="register"?"new-password":"current-password";setNotice("auth-notice","");
}));
$("auth-form").addEventListener("submit",async e=>{
  e.preventDefault();setNotice("auth-notice","Connexion en cours…",true);
  try{
    let data;
    if(mode==="register"){
      const identifier=$("identifier").value.trim();
      data=await api("/api/auth/register",{method:"POST",body:JSON.stringify({
        displayName:$("displayName").value.trim(),
        email:identifier.includes("@")?identifier:null,
        phone:$("phone").value.trim()||(!identifier.includes("@")?identifier:null),
        password:$("password").value
      })});
    }else data=await api("/api/auth/login",{method:"POST",body:JSON.stringify({identifier:$("identifier").value.trim(),password:$("password").value})});
    token=data.token;currentUser=data.user;localStorage.setItem("kco_token",token);showApp();
  }catch(err){setNotice("auth-notice",err.message);}
});
function connectSocket(){
  if(socket)socket.disconnect();
  socket=io({auth:{token}});
  socket.on("new-message",m=>{if(currentGroup&&Number(m.group_id)===Number(currentGroup.id))renderMessage(m);});
  socket.on("join-request",d=>alert(`Nouvelle demande pour « ${d.groupName} » de ${d.user.displayName}.`));
  socket.on("request-approved",d=>{alert(`Votre demande pour « ${d.groupName} » a été acceptée.`);loadGroups();});
  socket.on("app-error",d=>setNotice("chat-notice",d.message));
}
async function loadGroups(){
  try{const {groups}=await api("/api/groups");const list=$("groups-list");list.innerHTML="";
    if(!groups.length)list.innerHTML='<p class="muted">Aucun groupe pour le moment.</p>';
    groups.forEach(g=>{const row=document.createElement("div");row.className="group-item";
      const label=document.createElement("div");const title=document.createElement("strong");title.textContent=g.name;
      const sub=document.createElement("small");sub.textContent=g.role==="owner"?"Propriétaire": "Membre";label.append(title,sub);
      const button=document.createElement("button");button.className="secondary";button.textContent="Ouvrir";button.onclick=()=>openGroup(g);
      row.append(label,button);list.append(row);
    });
  }catch(e){setNotice("chat-notice",e.message);}
}
async function openGroup(g){
  currentGroup=g;$("chat-title").textContent=g.name;$("chat").innerHTML='<p class="muted">Chargement…</p>';
  socket.emit("join-group",g.id);
  try{const {messages}=await api(`/api/groups/${g.id}/messages`);$("chat").innerHTML="";messages.forEach(renderMessage);}
  catch(e){$("chat").innerHTML="";setNotice("chat-notice",e.message);}
}
function renderMessage(m){
  const chat=$("chat");const bubble=document.createElement("div");bubble.className="bubble"+(String(m.user_id)===String(currentUser.id)?" mine":"");
  const text=document.createElement("div");text.textContent=`${m.display_name||"Utilisateur"} : ${m.body}`;
  const meta=document.createElement("small");meta.textContent=new Date(m.created_at).toLocaleString("fr-FR");
  bubble.append(text,meta);chat.append(bubble);chat.scrollTop=chat.scrollHeight;
}
$("group-form").addEventListener("submit",async e=>{e.preventDefault();try{
  const data=await api("/api/groups",{method:"POST",body:JSON.stringify({name:$("group-name").value,description:$("group-description").value})});
  $("group-name").value="";$("group-description").value="";
  alert(`Groupe créé ! Code d’invitation à partager : ${data.group.invite_code}`);await loadGroups();await openGroup(data.group);
}catch(err){alert(err.message);}});
$("join-form").addEventListener("submit",async e=>{e.preventDefault();try{
  const data=await api("/api/groups/join-request",{method:"POST",body:JSON.stringify({inviteCode:$("invite-code").value})});
  setNotice("chat-notice",data.message,true);$("invite-code").value="";
}catch(err){setNotice("chat-notice",err.message);}});
$("message-form").addEventListener("submit",e=>{e.preventDefault();if(!currentGroup)return setNotice("chat-notice","Ouvrez d’abord un groupe.");
  const body=$("message-body").value.trim();if(!body)return;socket.emit("send-message",{groupId:currentGroup.id,body});$("message-body").value="";});
$("media-form").addEventListener("submit",async e=>{e.preventDefault();try{
  await api("/api/media",{method:"POST",body:JSON.stringify({mediaType:$("media-type").value,mediaUrl:$("media-url").value,caption:$("media-caption").value})});
  $("media-url").value="";$("media-caption").value="";await loadMedia();
}catch(err){alert(err.message);}});
async function loadMedia(){try{const {posts}=await api("/api/media");const list=$("media-list");list.innerHTML="";
  if(!posts.length){list.innerHTML='<p class="muted">Aucune publication pour le moment.</p>';return;}
  posts.forEach(p=>{const item=document.createElement("article");item.className="media-item";
    const type=document.createElement("strong");type.textContent=p.media_type.toUpperCase();
    const caption=document.createElement("p");caption.textContent=p.caption||"";
    const link=document.createElement("a");link.href=p.media_url;link.target="_blank";link.rel="noopener noreferrer";link.textContent="Ouvrir le média";
    const meta=document.createElement("small");meta.textContent=`${p.display_name} · ${new Date(p.created_at).toLocaleDateString("fr-FR")}`;
    item.append(type,caption,link,meta);list.append(item);
  });
}catch(e){console.error(e);}}
$("logout").addEventListener("click",()=>{localStorage.removeItem("kco_token");token=null;currentUser=null;currentGroup=null;showAuth();});
(async function init(){if(!token)return showAuth();try{const data=await api("/api/me");currentUser=data.user;showApp();}catch(_){localStorage.removeItem("kco_token");token=null;showAuth();}})();
