# Konũ Cheikh Oumar

Base de projet Node.js, Express, Socket.IO et PostgreSQL pour une messagerie de groupe.

## Fonctionnalités présentes dans ce socle
- Création de compte avec e-mail ou téléphone comme identifiant (mot de passe requis).
- Connexion sécurisée avec hachage bcrypt et jeton JWT.
- Création de groupes et code d’invitation généré par le propriétaire.
- Demande d’adhésion et approbation/refus par le propriétaire via API.
- Messagerie temps réel avec Socket.IO, réservée aux membres du groupe.
- Fil de médias par liens HTTP/HTTPS avec date de publication.
- Configuration de déploiement Render dans `render.yaml`.

## Installation locale
Prérequis : Node.js 20+ et PostgreSQL.

1. Créez une base PostgreSQL.
2. Exécutez `database/schema.sql` sur cette base.
3. Copiez `.env.example` en `.env`, puis renseignez `DATABASE_URL` et un `JWT_SECRET` long et aléatoire.
4. Installez et lancez :

```bash
npm install
npm start
```

Ouvrez `http://localhost:3000`.

## Déploiement Render
1. Envoyez le dossier sur GitHub.
2. Dans Render, créez un Blueprint à partir du dépôt, ou créez un Web Service Node.
3. Le service doit utiliser `npm install` comme commande de build et `npm start` comme commande de démarrage.
4. Créez PostgreSQL et configurez `DATABASE_URL` avec l’URL interne du service de base.
5. Exécutez `database/schema.sql` une fois sur la base Render.
6. Définissez `JWT_SECRET` avec une valeur aléatoire forte et activez SSL PostgreSQL si requis par votre fournisseur.

## Important avant une mise en production
- Le code de base n’envoie pas de SMS ni d’e-mail de vérification : le téléphone est un identifiant, pas une authentification par OTP.
- Les appels audio/vidéo ne sont pas encore intégrés. Ils nécessitent une signalisation WebRTC et, en production, généralement un service STUN/TURN.
- Les fichiers médias sont référencés par URL ; ce projet n’inclut pas encore le stockage/téléversement des fichiers.
- Ajoutez limitation de débit, vérification e-mail/téléphone, politique de confidentialité, sauvegardes DB et tests de sécurité avant d’ouvrir l’application au public.
- Ne publiez jamais le fichier `.env` ni vos mots de passe.
